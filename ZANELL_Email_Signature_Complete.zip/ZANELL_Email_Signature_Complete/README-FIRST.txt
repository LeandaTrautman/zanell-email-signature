ZANELL EMAIL SIGNATURE PACKAGE
==============================

This package contains two versions:
01-Mac/
    signature-mac.html
    Optimised for Apple Mail on Mac.

02-iPhone/
    signature-iphone.html
    Smaller, more compact version for iPhone Mail.

03-Hosting/
    The four PNG files that need to be hosted publicly.

IMPORTANT:
The HTML files currently contain:
https://YOUR-HOSTING-URL/

This is intentional. Replace that placeholder with the final public hosting folder URL after the images are uploaded.

WHY HOST THE IMAGES?
Email signatures should not depend on local files on the client's computer. Public image URLs let recipients' email clients retrieve the logo/icons when the message is displayed.

MAC INSTALLATION
----------------
1. Open the Mac HTML file in Safari/Chrome.
2. Select the rendered signature and copy it.
3. In Apple Mail, open Mail > Settings > Signatures.
4. Create the client's signature.
5. Paste the rendered signature into the signature editor.
6. Send a test email to Gmail and another Apple Mail address.
7. Close and reopen Mail and check that the signature remains.
8. If Mail strips the formatting, use the HTML signature-file installation method instead of repeatedly pasting.

IPHONE INSTALLATION
-------------------
Apple's iPhone Mail app does not provide a normal "import HTML signature" button.
The practical method is:
1. Open the iPhone HTML signature in Safari.
2. Select/copy the rendered signature.
3. Go to Settings > Apps > Mail > Signature.
4. Paste the signature into the account's signature field.
5. Send a test email.
6. If the iPhone alters the formatting, use the hosted-image version and keep the signature compact.

BASE64 OPTION
-------------
A Base64-embedded version is deliberately not included as the primary solution. Many email clients handle externally hosted images more predictably, and Base64 makes the signature unnecessarily large.

CLIENT HANDOVER
---------------
Give the client the installation instructions, not the editable hosting files unless she needs them.
Keep the hosting folder and master HTML files in your own project archive.
