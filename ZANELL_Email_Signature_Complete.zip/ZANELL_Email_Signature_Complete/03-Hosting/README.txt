HOST THESE FOUR FILES PUBLICLY
================================

Upload these files to one public static folder:
- zanell-logo.png
- phone.png
- email.png
- location.png

Then replace YOUR-HOSTING-URL in both HTML files with the exact public folder URL.

Example:
https://yourdomain.example/zanell-signature/

The final image URLs would be:
https://yourdomain.example/zanell-signature/zanell-logo.png
https://yourdomain.example/zanell-signature/phone.png
https://yourdomain.example/zanell-signature/email.png
https://yourdomain.example/zanell-signature/location.png

IMPORTANT:
Do not use a normal Google Drive/Dropbox sharing URL. The email client needs direct public image URLs.

RECOMMENDED HOSTING:
Use GitHub Pages, Cloudflare Pages, or the client's future website hosting.
For the cleanest long-term setup, move these four files to her own website hosting when the website exists.
